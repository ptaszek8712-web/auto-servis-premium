# Auto Servis Premium

Startowy projekt Android (Kotlin + Jetpack Compose) z ciemnym panelem głównym.

## Otwieranie
1. Zainstaluj Android Studio na komputerze.
2. Otwórz folder `AutoServisPremium` jako projekt.
3. Poczekaj na synchronizację Gradle.
4. Uruchom na emulatorze lub telefonie z włączonym debugowaniem USB.

## Ważne
To pierwszy szkielet projektu, a nie gotowa aplikacja. Integracje Firebase, AI i OBD-II wymagają dalszej implementacji i konfiguracji. Nie zawiera kluczy API ani danych użytkownika.

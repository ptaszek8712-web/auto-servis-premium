package pl.autoservis.premium

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF151F30)
private val Accent = Color(0xFF55B7FF)
private val Muted = Color(0xFF9AA9BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutoServisApp() }
    }
}

@Composable
fun AutoServisApp() {
    var selected by remember { mutableStateOf("Pulpit") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Pulpit" to Icons.Default.Dashboard, "Garaż" to Icons.Default.DirectionsCar,
                    "Serwis" to Icons.Default.Build, "Koszty" to Icons.Default.BarChart, "Więcej" to Icons.Default.Menu)
                    .forEach { (label, icon) ->
                        NavigationBarItem(selected == label, onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                    }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("AUTO SERVIS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("PREMIUM", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Surface(color = Color(0xFF18334A), shape = RoundedCornerShape(50)) {
                        Text("● GOTOWY", color = Color(0xFF75D6A0), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(22.dp))
                if (selected == "Pulpit") Dashboard() else ModuleScreen(selected)
            }
        }
    }
}

@Composable
private fun Dashboard() {
    Text("Twój garaż", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(8.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("WITAJ W AUTO SERVIS PREMIUM", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("Zadbaj o swój samochód.", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Dodaj pojazd, aby rozpocząć prowadzenie historii serwisowej.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Dodaj pierwszy samochód") }
        }
    }
    Spacer(Modifier.height(20.dp))
    Text("Szybki dostęp", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    val modules = listOf("AI Mechanik" to Icons.Default.SmartToy, "Historia serwisu" to Icons.Default.Build,
        "OC i przeglądy" to Icons.Default.Event, "Tankowania" to Icons.Default.LocalGasStation,
        "Koszty" to Icons.Default.Payments, "Dokumenty" to Icons.Default.Folder)
    LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(modules.size) { i ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Icon(modules[i].second, null, tint = Accent, modifier = Modifier.size(27.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(modules[i].first, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Otwórz moduł", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ModuleScreen(name: String) {
    Text(name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(18.dp)) {
            Text("Moduł przygotowany do rozbudowy", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("W kolejnym etapie dodamy formularze, bazę danych i pełną obsługę funkcji: $name.", color = Muted)
        }
    }
}

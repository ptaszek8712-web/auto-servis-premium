# Auto Servis Premium — projekt techniczny

## Cel
Androidowa aplikacja do zarządzania wieloma pojazdami, serwisem, dokumentami, terminami, tankowaniami i kosztami. Działa offline, a po konfiguracji backendu synchronizuje dane z chmurą.

## Stos technologiczny
- Kotlin, Jetpack Compose, Material 3
- Room jako lokalna baza danych i źródło prawdy offline
- WorkManager do kolejkowania synchronizacji i przypomnień
- Firebase Authentication, Firestore i Storage jako docelowa warstwa chmurowa
- AI przez bezpieczny backend pośredniczący; klucz API nigdy nie trafia do APK
- OBD-II przez Bluetooth jako osobny, opcjonalny moduł

## Moduły funkcjonalne
1. Garaż i profile pojazdów: marka, model, rocznik, VIN, rejestracja, silnik, paliwo, przebieg.
2. Serwis: wpisy napraw, części, robocizna, warsztat, przebieg, zdjęcia i załączniki.
3. Terminy: OC/AC, badanie techniczne, wymiana oleju, rozrząd, opony; powiadomienia lokalne.
4. Tankowania: ilość, cena/litr, kwota, przebieg, stacja, pełny bak; wyliczanie spalania.
5. Finanse: kategorie kosztów, wykresy miesięczne/roczne, koszt/km.
6. Dokumenty: polisy, faktury, dowód rejestracyjny; pliki prywatne.
7. AI Mechanik: wywiad objawów, możliwe przyczyny, poziom pilności, pytania doprecyzowujące; bez udawania pewnej diagnozy.
8. OBD-II: odczyt DTC i parametrów po dobraniu kompatybilnego adaptera.
9. Synchronizacja: kolejka zmian, identyfikatory UUID, znaczniki czasu, rozwiązywanie konfliktów i kopie zapasowe.

## Bezpieczeństwo i prywatność
- Minimalne uprawnienia Androida; lokalne dane nie są wysyłane bez zgody.
- Firebase Security Rules per użytkownik; pliki prywatne.
- Sekrety i klucze AI przechowywane wyłącznie po stronie backendu.
- Eksport i usuwanie danych użytkownika.
- Walidacja danych oraz obsługa braku internetu.

## Etapy realizacji
- Etap 1: szkielet Android, nawigacja i ciemny interfejs (rozpoczęty).
- Etap 2: Room, encje i formularze CRUD dla pojazdów, serwisu, tankowań i terminów.
- Etap 3: powiadomienia, raporty i eksport danych.
- Etap 4: Firebase Auth/Firestore/Storage i synchronizacja offline-first (wymaga projektu Firebase użytkownika).
- Etap 5: backend AI i moduł AI Mechanik (wymaga wyboru dostawcy i konfiguracji klucza).
- Etap 6: OBD-II, testy na urządzeniu, podpisanie i wydanie APK.

## Stan prototypu
Repozytorium zawiera startowy projekt Android z ciemnym pulpitem, dolną nawigacją i ekranami modułów. Nie jest to jeszcze kompletna aplikacja produkcyjna ani gotowy APK. Budowanie wymaga Android SDK i Gradle w Android Studio.
